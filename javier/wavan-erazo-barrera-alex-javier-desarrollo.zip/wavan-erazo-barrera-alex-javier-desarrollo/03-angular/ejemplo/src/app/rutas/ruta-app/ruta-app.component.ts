import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-app',
  templateUrl: './ruta-app.component.html',
  styleUrls: ['./ruta-app.component.scss']
})
export class RutaAppComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
