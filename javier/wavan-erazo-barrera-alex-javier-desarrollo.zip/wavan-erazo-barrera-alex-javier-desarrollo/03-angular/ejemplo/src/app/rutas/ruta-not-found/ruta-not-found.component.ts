import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-not-found',
  templateUrl: './ruta-not-found.component.html',
  styleUrls: ['./ruta-not-found.component.scss']
})
export class RutaNotFoundComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
