import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-post',
  templateUrl: './ruta-post.component.html',
  styleUrls: ['./ruta-post.component.scss']
})
export class RutaPostComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
