import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-forbidden',
  templateUrl: './ruta-forbidden.component.html',
  styleUrls: ['./ruta-forbidden.component.scss']
})
export class RutaForbiddenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
