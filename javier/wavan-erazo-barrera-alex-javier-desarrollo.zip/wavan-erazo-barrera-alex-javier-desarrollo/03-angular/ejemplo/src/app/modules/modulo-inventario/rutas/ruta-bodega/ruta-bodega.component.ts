import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-bodega',
  templateUrl: './ruta-bodega.component.html',
  styleUrls: ['./ruta-bodega.component.scss']
})
export class RutaBodegaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
