import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ruta-reporte',
  templateUrl: './ruta-reporte.component.html',
  styleUrls: ['./ruta-reporte.component.scss']
})
export class RutaReporteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
