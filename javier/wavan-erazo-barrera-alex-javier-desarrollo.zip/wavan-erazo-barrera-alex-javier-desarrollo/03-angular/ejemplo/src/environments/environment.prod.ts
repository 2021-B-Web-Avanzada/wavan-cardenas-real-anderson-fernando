export const environment = {
  production: true,
  urlJPC: 'https://placeholer.tipycode.com'
};
